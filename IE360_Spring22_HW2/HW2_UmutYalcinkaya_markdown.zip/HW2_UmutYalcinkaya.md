## IE360 Forecasting and Timeseries Homework 2

### 1. Introduction

The relationship between quarterly gasoline sales and other variables is explored in this study, which covers the years 2000 to 2006. The goal is to forecast quarterly unleaded gasoline sales for each quarter of 2007. To accomplish this, first visualize the objective variable, unleaded gasoline sale (UGS). Second, the given data is evaluated, and a suitable time series regression for the target variable is constructed. Finally, this model is used to make predictions.

The given data includes quarterly factors, the rate of new unleaded gasoline-using vehicles being added to the traffic(RNUV), average price of a liter of unleaded gasoline(PU), average price of a liter of diesel gasoline(PG), number of unleaded gasoline-using vehicles in the traffic(NUGV), number of diesel gasoline-using vehicles in the traffic per 1000 people(NDGV), number of LPG-using vehicles in the traffic(NPLG), agriculture component of GNP(GNPA), commercial component of GNP(GNPC), total GNP(GNPT). Furthermore, when creating the model for future predictions, lagged values of these variables are also used.



```R
library(readxl)
library(ggplot2)
library(dplyr)
library(tidyr)
library(lubridate)
library(RColorBrewer)
library(zoo)
library(tidyverse)
library(reshape2)
library(ggcorrplot)
```

    Registered S3 methods overwritten by 'ggplot2':
      method         from 
      [.quosures     rlang
      c.quosures     rlang
      print.quosures rlang
    
    Attaching package: 'dplyr'
    
    The following objects are masked from 'package:stats':
    
        filter, lag
    
    The following objects are masked from 'package:base':
    
        intersect, setdiff, setequal, union
    
    
    Attaching package: 'lubridate'
    
    The following object is masked from 'package:base':
    
        date
    
    
    Attaching package: 'zoo'
    
    The following objects are masked from 'package:base':
    
        as.Date, as.Date.numeric
    
    Registered S3 method overwritten by 'rvest':
      method            from
      read_xml.response xml2
    -- Attaching packages --------------------------------------- tidyverse 1.2.1 --
    v tibble  2.1.1     v purrr   0.3.2
    v readr   1.3.1     v stringr 1.4.0
    v tibble  2.1.1     v forcats 0.4.0
    -- Conflicts ------------------------------------------ tidyverse_conflicts() --
    x lubridate::as.difftime() masks base::as.difftime()
    x lubridate::date()        masks base::date()
    x dplyr::filter()          masks stats::filter()
    x lubridate::intersect()   masks base::intersect()
    x dplyr::lag()             masks stats::lag()
    x lubridate::setdiff()     masks base::setdiff()
    x lubridate::union()       masks base::union()
    
    Attaching package: 'reshape2'
    
    The following object is masked from 'package:tidyr':
    
        smiths
    
    Warning message:
    "package 'ggcorrplot' was built under R version 3.6.3"

### 2. Data Manuplation

Data manuplation is made below for easier visualization and analysis of given data. Values are converted to numeric. Date column is converted to date class from string and it is also seperated to 2 different year and quarter column.


```R
setwd("C:/Users/Umut/Desktop/dersler/IE 360/HW2")
gasoline<-read.csv(file="IE360_Spring22_HW2_data.csv",header=TRUE)
colnames(gasoline) <- c("Date","UGS","RNUV","NLPG","PU","PG","NUGV","NDGV","GNPA","GNPC","GNPT")

str(gasoline)

gasoline$Date<-gsub('_',' ', gasoline$Date)
gasoline$UGS<-gsub(' ','', gasoline$UGS)
gasoline$NLPG<-gsub(' ','', gasoline$NLPG)
gasoline$NUGV<-gsub(' ','', gasoline$NUGV)
gasoline$GNPA<-gsub(' ','', gasoline$GNPA)
gasoline$GNPC<-gsub(' ','', gasoline$GNPC)
gasoline$GNPT<-gsub(' ','', gasoline$GNPT)

gasoline$UGS <- as.numeric(gasoline$UGS) 
gasoline$NLPG <- as.numeric(gasoline$NLPG) 
gasoline$NUGV <- as.numeric(gasoline$NUGV) 
gasoline$GNPA <- as.numeric(gasoline$GNPA) 
gasoline$GNPC <- as.numeric(gasoline$GNPC) 
gasoline$GNPT <- as.numeric(gasoline$GNPT) 

gasoline <- gasoline %>% mutate(Year = case_when(
    grepl("2000", gasoline$Date, fixed = TRUE) ~ 2000,    
    grepl("2001", gasoline$Date, fixed = TRUE) ~ 2001,    
    grepl("2002", gasoline$Date, fixed = TRUE) ~ 2002,    
    grepl("2003", gasoline$Date, fixed = TRUE) ~ 2003,    
    grepl("2004", gasoline$Date, fixed = TRUE) ~ 2004,    
    grepl("2005", gasoline$Date, fixed = TRUE) ~ 2005,    
    grepl("2006", gasoline$Date, fixed = TRUE) ~ 2006,    
    grepl("2007", gasoline$Date, fixed = TRUE) ~ 2007 ))

gasoline <- gasoline %>% mutate(Quarter = case_when(
  grepl("Q1", gasoline$Date, fixed = TRUE) ~ 1,    
  grepl("Q2", gasoline$Date, fixed = TRUE) ~ 2,    
  grepl("Q3", gasoline$Date, fixed = TRUE) ~ 3,    
  grepl("Q4", gasoline$Date, fixed = TRUE) ~ 4 ))

gasoline$Date <- paste(gasoline$Year, gasoline$Quarter, sep="-") %>% yq() %>% as.Date()
head(gasoline)
str(gasoline)

gasolinetraining <- gasoline[-c((nrow(gasoline)-3):nrow(gasoline)), ]
```

    'data.frame':	32 obs. of  11 variables:
     $ Date: Factor w/ 32 levels "2000_Q1","2000_Q2",..: 1 2 3 4 5 6 7 8 9 10 ...
     $ UGS : Factor w/ 29 levels ""," 736 580",..: 25 27 29 24 20 18 28 17 11 19 ...
     $ RNUV: num  0.01 0.02 0.02 0.02 0.01 0.01 0 0 0 0 ...
     $ NLPG: Factor w/ 32 levels " 940 000"," 941 000",..: 1 2 3 4 5 6 7 8 9 10 ...
     $ PU  : num  469 459 440 402 412 ...
     $ PG  : num  356 345 327 301 306 ...
     $ NUGV: Factor w/ 32 levels "4 647 500","4 742 876",..: 1 2 3 4 5 6 7 8 9 10 ...
     $ NDGV: num  282 284 287 288 288 ...
     $ GNPA: Factor w/ 32 levels " 832 953"," 841 604",..: 6 16 31 24 3 11 25 17 1 9 ...
     $ GNPC: Factor w/ 32 levels "3 374 849","3 418 387",..: 3 10 23 14 2 6 24 11 1 7 ...
     $ GNPT: Factor w/ 32 levels "15 832 648","18 022 686",..: 2 9 26 15 1 5 21 11 3 6 ...
    


<table>
<thead><tr><th scope=col>Date</th><th scope=col>UGS</th><th scope=col>RNUV</th><th scope=col>NLPG</th><th scope=col>PU</th><th scope=col>PG</th><th scope=col>NUGV</th><th scope=col>NDGV</th><th scope=col>GNPA</th><th scope=col>GNPC</th><th scope=col>GNPT</th><th scope=col>Year</th><th scope=col>Quarter</th></tr></thead>
<tbody>
	<tr><td>2000-01-01</td><td>1128971   </td><td>0.01      </td><td>940000    </td><td>469.03    </td><td>355.69    </td><td>4647500   </td><td>281.99    </td><td>1040173   </td><td>3483132   </td><td>18022686  </td><td>2000      </td><td>1         </td></tr>
	<tr><td>2000-04-01</td><td>1199569   </td><td>0.02      </td><td>941000    </td><td>459.42    </td><td>344.58    </td><td>4742876   </td><td>284.08    </td><td>1760460   </td><td>4525451   </td><td>21797130  </td><td>2000      </td><td>2         </td></tr>
	<tr><td>2000-07-01</td><td>1370167   </td><td>0.02      </td><td>943500    </td><td>439.98    </td><td>327.21    </td><td>4840931   </td><td>286.72    </td><td>6974808   </td><td>5915204   </td><td>30050207  </td><td>2000      </td><td>3         </td></tr>
	<tr><td>2000-10-01</td><td>1127548   </td><td>0.02      </td><td>948000    </td><td>402.08    </td><td>300.67    </td><td>4919685   </td><td>288.31    </td><td>3267125   </td><td>4929778   </td><td>24480153  </td><td>2000      </td><td>4         </td></tr>
	<tr><td>2001-01-01</td><td>1033918   </td><td>0.01      </td><td>950000    </td><td>411.58    </td><td>305.75    </td><td>4954754   </td><td>287.62    </td><td>1004528   </td><td>3418387   </td><td>15832648  </td><td>2001      </td><td>1         </td></tr>
	<tr><td>2001-04-01</td><td>1019754   </td><td>0.01      </td><td>955000    </td><td>520.39    </td><td>374.78    </td><td>4980204   </td><td>287.88    </td><td>1449357   </td><td>4359831   </td><td>20296918  </td><td>2001      </td><td>2         </td></tr>
</tbody>
</table>



    'data.frame':	32 obs. of  13 variables:
     $ Date   : Date, format: "2000-01-01" "2000-04-01" ...
     $ UGS    : num  1128971 1199569 1370167 1127548 1033918 ...
     $ RNUV   : num  0.01 0.02 0.02 0.02 0.01 0.01 0 0 0 0 ...
     $ NLPG   : num  940000 941000 943500 948000 950000 ...
     $ PU     : num  469 459 440 402 412 ...
     $ PG     : num  356 345 327 301 306 ...
     $ NUGV   : num  4647500 4742876 4840931 4919685 4954754 ...
     $ NDGV   : num  282 284 287 288 288 ...
     $ GNPA   : num  1040173 1760460 6974808 3267125 1004528 ...
     $ GNPC   : num  3483132 4525451 5915204 4929778 3418387 ...
     $ GNPT   : num  18022686 21797130 30050207 24480153 15832648 ...
     $ Year   : num  2000 2000 2000 2000 2001 ...
     $ Quarter: num  1 2 3 4 1 2 3 4 1 2 ...
    

### 3. Data Visualization

To visualize the UGS data, a timeseries conversion has been made. Time series graphs of each variable are also analized visually. At the first glance, it can be seen that seasonal characteristic of UGS graph is clear. This similar seasonalty can also bee seen at the GNPA, GNPC, GNPT graphs. However GNPC and GNPT have an upwards trend while UGS has a downward trend.

When UGS series are analyzed further, we can see that each years follows a similar characteristic. Gasoline sales increase up until 3rd quarter and then drop at the 4th quarter. 


```R
gasolinets <- ts(gasolinetraining[c(2,3,4,5,6,7,8,9,10,11)], freq=4, start=c(2000,1))

plot(gasolinets[,c(1:5)],main="Time Series",xlab="Date")
plot(gasolinets[,c(6:10)],main="Time Series",xlab="Date")

ggplot(gasolinetraining, aes(x=Date,y=UGS))+geom_line(color="red")+
  labs(x="Date",y="UGS",title="Quarterly Gasoline Sales")

ggplot(gasolinetraining,aes(x=factor(Quarter),y=UGS,colour = Quarter))+
  geom_bar(stat="identity", aes(fill=Quarter),color="black")+
  facet_wrap(gasolinetraining$Year)+
  labs(title="Quarterly UGS")

ggplot(gasolinetraining,aes(x=factor(Quarter),y=UGS))+
  geom_boxplot(aes(fill=factor(Quarter)))+
  theme(legend.position = "none")+
  labs(x="Quarter",title="Quarterly Sales Deviation")

correl_info = cor(gasolinetraining[2:13])

ggcorrplot(correl_info, type="lower", lab=TRUE)

acf(gasolinetraining$UGS, main="Autocorrelation of UGS")
```


    
![png](output_5_0.png)
    



    
![png](output_5_1.png)
    



    
![png](output_5_2.png)
    



    
![png](output_5_3.png)
    



    
![png](output_5_4.png)
    



    
![png](output_5_5.png)
    



    
![png](output_5_6.png)
    


Looking at the correlation matrix we can determine the most correlated variables and find out which variables give the simmilar type of information. For example GNPC and GNPT nearly perfectly correlates with each other, thus when a linear model is created model will probably sellect only one of them as significant. Simmilar high correlations are also present between PU-PG and NUGV-NDGV.

When the correlation of UGS with the other variables are looked into, most significant one turns out to be "Year" variable. It has a high negative correlation with the UGS which can be seen by just looking at the time series graph of UGS. This correlation values are going to be used while determining the variables for linear regression model. 

By analyzing the autocorrelation of UGS data, it is clear that there is a high auto correlation with lag 4. This will be considered while creating the regression model. One way to represent this correlation is to create a categorical Quarter variable. Each quarter will have its own coefficien to represent this seasonality.

### 4. Decomposition of UGS time series

While I did not use decomposition while predicting, for better understanding of the UGS series, I did following decomposition examples and analized them.


```R
addetive<-decompose(gasolinets[,1], type="additive")
plot(addetive)

multiplicative<-decompose(gasolinets[,1], type="multiplicative")
plot(multiplicative)

deseasonalized <- gasolinets[,1]/multiplicative$seasonal
acf(gasolinets[,1])
ts.plot(deseasonalized)
acf(deseasonalized)

detrend<-deseasonalized/multiplicative$trend
ts.plot(detrend)
acf(detrend, na.action = na.pass, lag = 12)
```


    
![png](output_8_0.png)
    



    
![png](output_8_1.png)
    



    
![png](output_8_2.png)
    



    
![png](output_8_3.png)
    



    
![png](output_8_4.png)
    



    
![png](output_8_5.png)
    



    
![png](output_8_6.png)
    


### 5. Creating the Regression Model for Prediction

To find the best variables for linear model, each variable is added one by one and R-squared vaues of the models are recorded. It is also beneficial to add these variables parralel to seasonality and trend variables since we know that there is a clear correlation by quarter and by year. Quarters will be added to the model as factors to better represent the seasonality.


```R
model <- lm(UGS~Year+factor(Quarter), data=gasoline)
summary(model)
#Adjusted R-squared:  0.8966 
```


    
    Call:
    lm(formula = UGS ~ Year + factor(Quarter), data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -81167 -31283  -3458  28640  94502 
    
    Coefficients:
                      Estimate Std. Error t value Pr(>|t|)    
    (Intercept)      109024714    9192636  11.860 2.79e-11 ***
    Year                -53989       4589 -11.764 3.28e-11 ***
    factor(Quarter)2    108035      25962   4.161 0.000377 ***
    factor(Quarter)3    246624      25962   9.500 2.00e-09 ***
    factor(Quarter)4     54557      25962   2.101 0.046759 *  
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 48570 on 23 degrees of freedom
      (4 observations deleted due to missingness)
    Multiple R-squared:  0.9119,	Adjusted R-squared:  0.8966 
    F-statistic: 59.53 on 4 and 23 DF,  p-value: 8.446e-12
    



```R
model <- lm(UGS~Year+factor(Quarter)+RNUV, data=gasoline)
summary(model)
#Adjusted R-squared:  0.909 Adding just RNUV improved model slightly
```


    
    Call:
    lm(formula = UGS ~ Year + factor(Quarter) + RNUV, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -84674 -19020  -1163  19098  98009 
    
    Coefficients:
                      Estimate Std. Error t value Pr(>|t|)    
    (Intercept)      109014193    8621302  12.645 1.45e-11 ***
    Year                -53989       4304 -12.543 1.69e-11 ***
    factor(Quarter)2     97514      24890   3.918 0.000737 ***
    factor(Quarter)3    236103      24890   9.486 3.13e-09 ***
    factor(Quarter)4     37022      25825   1.434 0.165761    
    RNUV               2454955    1205172   2.037 0.053857 .  
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 45550 on 22 degrees of freedom
      (4 observations deleted due to missingness)
    Multiple R-squared:  0.9259,	Adjusted R-squared:  0.909 
    F-statistic: 54.97 on 5 and 22 DF,  p-value: 1.074e-11
    



```R
model <- lm(UGS~Year+factor(Quarter)+NLPG, data=gasoline)
summary(model)
#Adjusted R-squared:  0.9313 Adding just NLPG improved model significantly
```


    
    Call:
    lm(formula = UGS ~ Year + factor(Quarter) + NLPG, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -83022 -23287   3235  18555  90847 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)    
    (Intercept)       1.945e+08  2.524e+07   7.709 1.09e-07 ***
    Year             -9.688e+04  1.265e+04  -7.657 1.21e-07 ***
    factor(Quarter)2  1.044e+05  2.119e+04   4.927 6.28e-05 ***
    factor(Quarter)3  2.340e+05  2.147e+04  10.901 2.46e-10 ***
    factor(Quarter)4  2.569e+04  2.268e+04   1.133   0.2695    
    NLPG              3.259e-01  9.184e-02   3.549   0.0018 ** 
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 39600 on 22 degrees of freedom
      (4 observations deleted due to missingness)
    Multiple R-squared:  0.944,	Adjusted R-squared:  0.9313 
    F-statistic: 74.15 on 5 and 22 DF,  p-value: 5.077e-13
    



```R
model <- lm(UGS~Year+factor(Quarter)+PU, data=gasoline)
summary(model)
#Adjusted R-squared:  0.9062  Adding just PU improved model sliglty
```


    
    Call:
    lm(formula = UGS ~ Year + factor(Quarter) + PU, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -61011 -30317  -3850  19446  96380 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)    
    (Intercept)      90431239.1 13393351.8   6.752 8.73e-07 ***
    Year               -44588.0     6735.5  -6.620 1.17e-06 ***
    factor(Quarter)2   117148.1    25216.3   4.646 0.000125 ***
    factor(Quarter)3   260291.0    25820.5  10.081 1.04e-09 ***
    factor(Quarter)4    58952.4    24837.9   2.373 0.026777 *  
    PU                   -474.8      258.9  -1.834 0.080178 .  
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 46250 on 22 degrees of freedom
      (4 observations deleted due to missingness)
    Multiple R-squared:  0.9236,	Adjusted R-squared:  0.9062 
    F-statistic: 53.19 on 5 and 22 DF,  p-value: 1.497e-11
    



```R
model <- lm(UGS~Year+factor(Quarter)+PG, data=gasoline)
summary(model)
#Adjusted R-squared:  0.901  Adding just PG did not improved model much
```


    
    Call:
    lm(formula = UGS ~ Year + factor(Quarter) + PG, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -70958 -29631  -9624  18714  97778 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)    
    (Intercept)      89765795.9 16273504.3   5.516 1.52e-05 ***
    Year               -44278.9     8180.4  -5.413 1.95e-05 ***
    factor(Quarter)2   113285.5    25673.7   4.413  0.00022 ***
    factor(Quarter)3   257631.6    26562.2   9.699 2.10e-09 ***
    factor(Quarter)4    59611.4    25654.2   2.324  0.02978 *  
    PG                   -497.0      349.9  -1.420  0.16958    
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 47530 on 22 degrees of freedom
      (4 observations deleted due to missingness)
    Multiple R-squared:  0.9193,	Adjusted R-squared:  0.901 
    F-statistic: 50.13 on 5 and 22 DF,  p-value: 2.712e-11
    



```R
model <- lm(UGS~Year+factor(Quarter)+NUGV, data=gasoline)
summary(model)
#Adjusted R-squared:  0.8933  Adding just NUGV reduced the model accuracy
```


    
    Call:
    lm(formula = UGS ~ Year + factor(Quarter) + NUGV, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -87256 -30446   1812  27878  86183 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)    
    (Intercept)       1.281e+08  3.682e+07   3.480 0.002125 ** 
    Year             -6.369e+04  1.870e+04  -3.406 0.002533 ** 
    factor(Quarter)2  1.050e+05  2.698e+04   3.891 0.000787 ***
    factor(Quarter)3  2.403e+05  2.886e+04   8.329    3e-08 ***
    factor(Quarter)4  4.426e+04  3.264e+04   1.356 0.188804    
    NUGV              6.856e-02  1.280e-01   0.536 0.597497    
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 49340 on 22 degrees of freedom
      (4 observations deleted due to missingness)
    Multiple R-squared:  0.913,	Adjusted R-squared:  0.8933 
    F-statistic:  46.2 on 5 and 22 DF,  p-value: 6.113e-11
    



```R
model <- lm(UGS~Year+factor(Quarter)+NDGV, data=gasoline)
summary(model)
#Adjusted R-squared:  0.9191   Adding just NDGV improved model sliglty
```


    
    Call:
    lm(formula = UGS ~ Year + factor(Quarter) + NDGV, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -95172 -20447   4988  23436  58473 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)    
    (Intercept)       1.478e+08  1.639e+07   9.016 7.67e-09 ***
    Year             -7.372e+04  8.309e+03  -8.872 1.02e-08 ***
    factor(Quarter)2  1.022e+05  2.306e+04   4.431  0.00021 ***
    factor(Quarter)3  2.347e+05  2.337e+04  10.042 1.12e-09 ***
    factor(Quarter)4  3.503e+04  2.405e+04   1.456  0.15949    
    NDGV              2.711e+03  9.961e+02   2.722  0.01245 *  
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 42950 on 22 degrees of freedom
      (4 observations deleted due to missingness)
    Multiple R-squared:  0.9341,	Adjusted R-squared:  0.9191 
    F-statistic: 62.37 on 5 and 22 DF,  p-value: 2.987e-12
    



```R
model <- lm(UGS~Year+factor(Quarter)+GNPA, data=gasoline)
summary(model)
#Adjusted R-squared:  0.9083   Adding just GNPA improved model sliglty
```


    
    Call:
    lm(formula = UGS ~ Year + factor(Quarter) + GNPA, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -75056 -30249  -2100  26158  95550 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)    
    (Intercept)       1.076e+08  8.687e+06  12.383 2.17e-11 ***
    Year             -5.330e+04  4.336e+03 -12.292 2.50e-11 ***
    factor(Quarter)2  7.476e+04  2.965e+04   2.522   0.0194 *  
    factor(Quarter)3 -9.582e+04  1.743e+05  -0.550   0.5881    
    factor(Quarter)4 -2.892e+04  4.866e+04  -0.594   0.5584    
    GNPA              6.066e-02  3.058e-02   1.984   0.0599 .  
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 45740 on 22 degrees of freedom
      (4 observations deleted due to missingness)
    Multiple R-squared:  0.9253,	Adjusted R-squared:  0.9083 
    F-statistic: 54.49 on 5 and 22 DF,  p-value: 1.174e-11
    



```R
model <- lm(UGS~Year+factor(Quarter)+GNPC, data=gasoline)
summary(model)
#Adjusted R-squared:  0.9177    Adding just GNPC improved model significantly
```


    
    Call:
    lm(formula = UGS ~ Year + factor(Quarter) + GNPC, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -82223 -21857   4657  21371  83997 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)    
    (Intercept)       1.557e+08  1.959e+07   7.949 6.57e-08 ***
    Year             -7.750e+04  9.852e+03  -7.867 7.79e-08 ***
    factor(Quarter)2  1.032e+04  4.385e+04   0.235   0.8161    
    factor(Quarter)3 -2.222e+04  1.050e+05  -0.212   0.8344    
    factor(Quarter)4 -9.808e+04  6.260e+04  -1.567   0.1315    
    GNPC              1.065e-01  4.059e-02   2.624   0.0155 *  
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 43340 on 22 degrees of freedom
      (4 observations deleted due to missingness)
    Multiple R-squared:  0.9329,	Adjusted R-squared:  0.9177 
    F-statistic: 61.19 on 5 and 22 DF,  p-value: 3.63e-12
    



```R
model <- lm(UGS~Year+factor(Quarter)+GNPT, data=gasoline)
summary(model)
#Adjusted R-squared:  0.9149    Adding just GNPT improved model significantly
```


    
    Call:
    lm(formula = UGS ~ Year + factor(Quarter) + GNPT, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -85086 -19853   1197  17853  88971 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)    
    (Intercept)       1.520e+08  1.948e+07   7.801 8.94e-08 ***
    Year             -7.563e+04  9.801e+03  -7.717 1.07e-07 ***
    factor(Quarter)2  4.511e+04  3.493e+04   1.291   0.2100    
    factor(Quarter)3  3.423e+03  1.025e+05   0.033   0.9736    
    factor(Quarter)4 -8.467e+04  6.175e+04  -1.371   0.1842    
    GNPT              2.077e-02  8.518e-03   2.439   0.0233 *  
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 44060 on 22 degrees of freedom
      (4 observations deleted due to missingness)
    Multiple R-squared:  0.9307,	Adjusted R-squared:  0.9149 
    F-statistic: 59.06 on 5 and 22 DF,  p-value: 5.203e-12
    


When we look at the above linear regression models the most improvement to the model is done by adding NLPG and GNPC variables. Thus, these two will be used in further models. I also think that adding some multiplicative variables will be beneficial to the accuracy of the model. With some trial and error following model is found that has an Adjusted R-squred value of 0.96.


```R
model <- lm(UGS~GNPC+NDGV*PG+GNPA*NLPG+Year+factor(Quarter), data=gasoline)
summary(model)
plot(model)
#Adjusted R-squared:  0.9602 
```


    
    Call:
    lm(formula = UGS ~ GNPC + NDGV * PG + GNPA * NLPG + Year + factor(Quarter), 
        data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -40101 -18651  -3401  15383  48023 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)    
    (Intercept)       1.324e+08  2.480e+07   5.338 6.67e-05 ***
    GNPC              1.791e-01  6.122e-02   2.925 0.009904 ** 
    NDGV             -6.184e+04  1.865e+04  -3.315 0.004377 ** 
    PG               -4.135e+04  1.193e+04  -3.464 0.003195 ** 
    GNPA             -3.266e-02  3.727e-02  -0.876 0.393852    
    NLPG              8.481e-02  1.142e-01   0.743 0.468369    
    Year             -5.678e+04  1.369e+04  -4.147 0.000757 ***
    factor(Quarter)2 -9.925e+03  4.377e+04  -0.227 0.823497    
    factor(Quarter)3  1.299e+05  1.415e+05   0.918 0.372116    
    factor(Quarter)4 -1.073e+05  5.616e+04  -1.911 0.074022 .  
    NDGV:PG           1.373e+02  4.021e+01   3.415 0.003545 ** 
    GNPA:NLPG        -1.720e-08  9.916e-09  -1.735 0.102035    
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 30130 on 16 degrees of freedom
      (4 observations deleted due to missingness)
    Multiple R-squared:  0.9764,	Adjusted R-squared:  0.9602 
    F-statistic: 60.24 on 11 and 16 DF,  p-value: 7.032e-11
    



    
![png](output_21_1.png)
    



    
![png](output_21_2.png)
    



    
![png](output_21_3.png)
    



    
![png](output_21_4.png)
    


Residuals seems to be somewhat close to normal distribution when looked at the Normal Q-Q plot. From the residuals vs fitted graph it can also be seen that residuals has a constant variance.

To improve this model further more lagged variables will be added. 

First Lag4 and Lag5 values of UGS variable is added to the model.


```R
gasoline$UGSlag5 <- lag(gasoline$UGS, n = 5L, default = NA)
gasoline$UGSlag4 <- lag(gasoline$UGS, n = 4L, default = NA)

model <- lm(UGS~GNPC+NDGV*PG+GNPA*NLPG+Year+factor(Quarter)+UGSlag4, data=gasoline)
summary(model)

model <- lm(UGS~GNPC+NDGV*PG+GNPA*NLPG+Year+factor(Quarter)+UGSlag5, data=gasoline)
summary(model)
```


    
    Call:
    lm(formula = UGS ~ GNPC + NDGV * PG + GNPA * NLPG + Year + factor(Quarter) + 
        UGSlag4, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -41518 -13768   2070  14210  37867 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)  
    (Intercept)       1.118e+08  6.906e+07   1.619   0.1337  
    GNPC              1.800e-01  6.970e-02   2.582   0.0255 *
    NDGV             -5.285e+04  2.375e+04  -2.226   0.0479 *
    PG               -3.586e+04  1.521e+04  -2.357   0.0380 *
    GNPA             -3.323e-02  5.715e-02  -0.582   0.5726  
    NLPG             -1.819e-03  1.514e-01  -0.012   0.9906  
    Year             -4.774e+04  3.374e+04  -1.415   0.1847  
    factor(Quarter)2  5.023e+03  6.134e+04   0.082   0.9362  
    factor(Quarter)3  1.392e+05  2.713e+05   0.513   0.6179  
    factor(Quarter)4 -9.104e+04  8.811e+04  -1.033   0.3237  
    UGSlag4          -2.774e-02  2.290e-01  -0.121   0.9058  
    NDGV:PG           1.181e+02  5.165e+01   2.286   0.0430 *
    GNPA:NLPG        -1.581e-08  1.248e-08  -1.267   0.2314  
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 30360 on 11 degrees of freedom
      (8 observations deleted due to missingness)
    Multiple R-squared:  0.9712,	Adjusted R-squared:  0.9398 
    F-statistic: 30.93 on 12 and 11 DF,  p-value: 1.02e-06
    



    
    Call:
    lm(formula = UGS ~ GNPC + NDGV * PG + GNPA * NLPG + Year + factor(Quarter) + 
        UGSlag5, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -43570 -14813   -318  18606  31724 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)  
    (Intercept)      -1.163e+07  1.136e+08  -0.102   0.9205  
    GNPC              2.204e-01  1.097e-01   2.009   0.0723 .
    NDGV             -4.680e+04  3.046e+04  -1.537   0.1554  
    PG               -3.120e+04  1.985e+04  -1.572   0.1470  
    GNPA             -4.954e-02  5.848e-02  -0.847   0.4167  
    NLPG             -1.628e-01  1.969e-01  -0.827   0.4277  
    Year              1.285e+04  5.624e+04   0.228   0.8239  
    factor(Quarter)2  3.535e+04  7.955e+04   0.444   0.6662  
    factor(Quarter)3  1.852e+05  3.029e+05   0.611   0.5545  
    factor(Quarter)4 -1.425e+05  1.527e+05  -0.933   0.3727  
    UGSlag5           4.042e-01  3.993e-01   1.012   0.3352  
    NDGV:PG           1.014e+02  6.683e+01   1.517   0.1603  
    GNPA:NLPG        -2.067e-08  1.348e-08  -1.534   0.1561  
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 30070 on 10 degrees of freedom
      (9 observations deleted due to missingness)
    Multiple R-squared:  0.9738,	Adjusted R-squared:  0.9424 
    F-statistic: 30.98 on 12 and 10 DF,  p-value: 2.784e-06
    


Adjusted R-squared value decreased after adding lag4 and lag5 values of UGS. Because of this reason, lagged values of UGS are removed from the model. 

Now, lagged versions of independent variables of the model is added.


```R
gasoline$RNUVlag1 <- lag(gasoline$RNUV, n = 1L, default = NA)
gasoline$NLPGlag1 <- lag(gasoline$NLPG, n = 1L, default = NA)
gasoline$PUlag1 <- lag(gasoline$PU, n = 1L, default = NA)
gasoline$PGlag1 <- lag(gasoline$PG, n = 1L, default = NA)
gasoline$NUGVlag1 <- lag(gasoline$NUGV, n = 1L, default = NA)
gasoline$NDGVlag1 <- lag(gasoline$NDGV, n = 1L, default = NA)
gasoline$GNPAlag1 <- lag(gasoline$GNPA, n = 1L, default = NA)
gasoline$GNPClag1 <- lag(gasoline$GNPC, n = 1L, default = NA)
gasoline$GNPTlag1 <- lag(gasoline$GNPT, n = 1L, default = NA)

model <- lm(UGS~GNPC+NDGV*PG+GNPA*NLPG+Year+factor(Quarter)+RNUVlag1, data=gasoline)
summary(model)
# Adding RNUVlag1 imrpoved the model: Adjusted R-squared = 0.9679 
model <- lm(UGS~GNPC+NDGV*PG+GNPA*NLPG+Year+factor(Quarter)+NLPGlag1, data=gasoline)
summary(model)
# Adding NLPGlag1 imrpoved the model: Adjusted R-squared =  0.9726 
model <- lm(UGS~GNPC+NDGV*PG+GNPA*NLPG+Year+factor(Quarter)+PUlag1, data=gasoline)
summary(model)
# Adding PUlag1 imrpoved the model: Adjusted R-squared =  0.9658 
model <- lm(UGS~GNPC+NDGV*PG+GNPA*NLPG+Year+factor(Quarter)+PGlag1, data=gasoline)
summary(model)
# Adding PGlag1 imrpoved the model: Adjusted R-squared =  0.9662 
model <- lm(UGS~GNPC+NDGV*PG+GNPA*NLPG+Year+factor(Quarter)+NUGVlag1, data=gasoline)
summary(model)
# Adding NUGVlag1 imrpoved the model: Adjusted R-squared = 0.9674  
model <- lm(UGS~GNPC+NDGV*PG+GNPA*NLPG+Year+factor(Quarter)+NDGVlag1, data=gasoline)
summary(model)
# Adding NDGVlag1 imrpoved the model: Adjusted R-squared = 0.9677  
model <- lm(UGS~GNPC+NDGV*PG+GNPA*NLPG+Year+factor(Quarter)+GNPAlag1, data=gasoline)
summary(model)
# Adding GNPAlag1 imrpoved the model: Adjusted R-squared = 0.9658  
model <- lm(UGS~GNPC+NDGV*PG+GNPA*NLPG+Year+factor(Quarter)+GNPClag1, data=gasoline)
summary(model)
# Adding GNPClag1 imrpoved the model: Adjusted R-squared =  0.9747  
model <- lm(UGS~GNPC+NDGV*PG+GNPA*NLPG+Year+factor(Quarter)+GNPTlag1, data=gasoline)
summary(model)
# Adding GNPTlag1 imrpoved the model: Adjusted R-squared =  0.971 
```


    
    Call:
    lm(formula = UGS ~ GNPC + NDGV * PG + GNPA * NLPG + Year + factor(Quarter) + 
        RNUVlag1, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -35563 -14490  -6169  17399  33947 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)   
    (Intercept)       1.266e+08  3.212e+07   3.942  0.00147 **
    GNPC              1.561e-01  5.815e-02   2.685  0.01777 * 
    NDGV             -5.098e+04  1.739e+04  -2.932  0.01093 * 
    PG               -3.495e+04  1.107e+04  -3.158  0.00698 **
    GNPA             -4.663e-03  4.152e-02  -0.112  0.91217   
    NLPG              8.071e-02  1.271e-01   0.635  0.53561   
    Year             -5.544e+04  1.687e+04  -3.287  0.00540 **
    factor(Quarter)2 -1.647e+03  4.097e+04  -0.040  0.96851   
    factor(Quarter)3  8.408e+04  1.462e+05   0.575  0.57439   
    factor(Quarter)4 -1.020e+05  5.395e+04  -1.890  0.07961 . 
    RNUVlag1         -1.324e+06  1.348e+06  -0.982  0.34269   
    NDGV:PG           1.154e+02  3.735e+01   3.088  0.00801 **
    GNPA:NLPG        -2.468e-08  1.022e-08  -2.415  0.03000 * 
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 27110 on 14 degrees of freedom
      (5 observations deleted due to missingness)
    Multiple R-squared:  0.9827,	Adjusted R-squared:  0.9679 
    F-statistic: 66.31 on 12 and 14 DF,  p-value: 3.392e-10
    



    
    Call:
    lm(formula = UGS ~ GNPC + NDGV * PG + GNPA * NLPG + Year + factor(Quarter) + 
        NLPGlag1, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -39100  -9035   3237   9810  43679 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)   
    (Intercept)       8.866e+07  2.515e+07   3.525  0.00336 **
    GNPC              1.430e-01  5.351e-02   2.673  0.01820 * 
    NDGV             -6.095e+04  1.653e+04  -3.686  0.00244 **
    PG               -4.061e+04  1.049e+04  -3.872  0.00169 **
    GNPA             -3.228e-02  3.106e-02  -1.039  0.31636   
    NLPG             -3.604e-01  2.219e-01  -1.624  0.12660   
    Year             -3.497e+04  1.351e+04  -2.588  0.02147 * 
    factor(Quarter)2  4.004e+04  4.103e+04   0.976  0.34575   
    factor(Quarter)3  2.828e+05  1.362e+05   2.076  0.05681 . 
    factor(Quarter)4 -1.366e+04  6.103e+04  -0.224  0.82613   
    NLPGlag1          4.873e-01  2.579e-01   1.889  0.07973 . 
    NDGV:PG           1.336e+02  3.536e+01   3.777  0.00204 **
    GNPA:NLPG        -2.250e-08  8.426e-09  -2.671  0.01827 * 
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 25020 on 14 degrees of freedom
      (5 observations deleted due to missingness)
    Multiple R-squared:  0.9853,	Adjusted R-squared:  0.9726 
    F-statistic: 78.05 on 12 and 14 DF,  p-value: 1.115e-10
    



    
    Call:
    lm(formula = UGS ~ GNPC + NDGV * PG + GNPA * NLPG + Year + factor(Quarter) + 
        PUlag1, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -41812 -13155    174  15854  41298 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)   
    (Intercept)       1.089e+08  2.694e+07   4.041  0.00121 **
    GNPC              1.790e-01  5.973e-02   2.997  0.00960 **
    NDGV             -5.058e+04  1.973e+04  -2.563  0.02254 * 
    PG               -3.449e+04  1.250e+04  -2.759  0.01538 * 
    GNPA             -3.074e-02  3.559e-02  -0.864  0.40229   
    NLPG              8.359e-03  1.135e-01   0.074  0.94231   
    Year             -4.663e+04  1.465e+04  -3.184  0.00663 **
    factor(Quarter)2  3.022e+03  4.357e+04   0.069  0.94569   
    factor(Quarter)3  1.461e+05  1.352e+05   1.080  0.29827   
    factor(Quarter)4 -9.370e+04  6.065e+04  -1.545  0.14469   
    PUlag1            7.765e+01  2.990e+02   0.260  0.79890   
    NDGV:PG           1.131e+02  4.276e+01   2.645  0.01922 * 
    GNPA:NLPG        -1.886e-08  1.020e-08  -1.849  0.08566 . 
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 27960 on 14 degrees of freedom
      (5 observations deleted due to missingness)
    Multiple R-squared:  0.9816,	Adjusted R-squared:  0.9658 
    F-statistic: 62.26 on 12 and 14 DF,  p-value: 5.203e-10
    



    
    Call:
    lm(formula = UGS ~ GNPC + NDGV * PG + GNPA * NLPG + Year + factor(Quarter) + 
        PGlag1, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -42575 -12699    226  16082  42266 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)   
    (Intercept)       1.119e+08  2.775e+07   4.032  0.00123 **
    GNPC              1.817e-01  5.861e-02   3.100  0.00783 **
    NDGV             -4.900e+04  1.940e+04  -2.526  0.02420 * 
    PG               -3.351e+04  1.231e+04  -2.722  0.01652 * 
    GNPA             -3.353e-02  3.593e-02  -0.933  0.36654   
    NLPG              6.651e-03  1.116e-01   0.060  0.95331   
    Year             -4.838e+04  1.510e+04  -3.205  0.00636 **
    factor(Quarter)2  1.788e+03  4.232e+04   0.042  0.96690   
    factor(Quarter)3  1.518e+05  1.311e+05   1.158  0.26615   
    factor(Quarter)4 -9.613e+04  5.678e+04  -1.693  0.11258   
    PGlag1            1.678e+02  3.497e+02   0.480  0.63871   
    NDGV:PG           1.096e+02  4.202e+01   2.608  0.02067 * 
    GNPA:NLPG        -1.834e-08  9.825e-09  -1.867  0.08297 . 
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 27800 on 14 degrees of freedom
      (5 observations deleted due to missingness)
    Multiple R-squared:  0.9818,	Adjusted R-squared:  0.9662 
    F-statistic: 62.99 on 12 and 14 DF,  p-value: 4.805e-10
    



    
    Call:
    lm(formula = UGS ~ GNPC + NDGV * PG + GNPA * NLPG + Year + factor(Quarter) + 
        NUGVlag1, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -45349 -12107     82  14086  36224 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)  
    (Intercept)       2.467e+07  9.936e+07   0.248   0.8075  
    GNPC              1.366e-01  7.087e-02   1.927   0.0745 .
    NDGV             -3.438e+04  2.766e+04  -1.243   0.2343  
    PG               -2.597e+04  1.600e+04  -1.623   0.1269  
    GNPA             -3.852e-02  3.577e-02  -1.077   0.2998  
    NLPG             -1.224e-01  1.931e-01  -0.634   0.5363  
    Year             -6.053e+03  4.781e+04  -0.127   0.9011  
    factor(Quarter)2  4.486e+04  6.025e+04   0.744   0.4689  
    factor(Quarter)3  3.043e+05  2.177e+05   1.398   0.1839  
    factor(Quarter)4 -3.172e+03  1.098e+05  -0.029   0.9774  
    NUGVlag1         -2.806e-01  3.276e-01  -0.857   0.4060  
    NDGV:PG           8.394e+01  5.466e+01   1.536   0.1469  
    GNPA:NLPG        -1.853e-08  9.232e-09  -2.007   0.0645 .
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 27320 on 14 degrees of freedom
      (5 observations deleted due to missingness)
    Multiple R-squared:  0.9824,	Adjusted R-squared:  0.9674 
    F-statistic: 65.26 on 12 and 14 DF,  p-value: 3.777e-10
    



    
    Call:
    lm(formula = UGS ~ GNPC + NDGV * PG + GNPA * NLPG + Year + factor(Quarter) + 
        NDGVlag1, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -37280 -12439   1821  17121  41192 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)    
    (Intercept)       1.193e+08  2.844e+07   4.196 0.000897 ***
    GNPC              1.879e-01  5.715e-02   3.288 0.005391 ** 
    NDGV             -7.203e+04  2.684e+04  -2.683 0.017827 *  
    PG               -4.308e+04  1.348e+04  -3.195 0.006479 ** 
    GNPA             -2.327e-02  3.416e-02  -0.681 0.506832    
    NLPG              1.188e-01  1.549e-01   0.767 0.455840    
    Year             -4.994e+04  1.428e+04  -3.498 0.003548 ** 
    factor(Quarter)2  9.064e+02  4.067e+04   0.022 0.982534    
    factor(Quarter)3  1.145e+05  1.348e+05   0.850 0.409808    
    factor(Quarter)4 -1.001e+05  5.372e+04  -1.863 0.083515 .  
    NDGVlag1          7.800e+03  8.300e+03   0.940 0.363273    
    NDGV:PG           1.428e+02  4.573e+01   3.122 0.007504 ** 
    GNPA:NLPG        -2.260e-08  9.467e-09  -2.387 0.031643 *  
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 27190 on 14 degrees of freedom
      (5 observations deleted due to missingness)
    Multiple R-squared:  0.9826,	Adjusted R-squared:  0.9677 
    F-statistic: 65.94 on 12 and 14 DF,  p-value: 3.522e-10
    



    
    Call:
    lm(formula = UGS ~ GNPC + NDGV * PG + GNPA * NLPG + Year + factor(Quarter) + 
        GNPAlag1, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -40280 -13883  -1077  15111  39788 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)   
    (Intercept)       1.073e+08  2.598e+07   4.129  0.00102 **
    GNPC              1.809e-01  6.358e-02   2.845  0.01297 * 
    NDGV             -5.399e+04  1.859e+04  -2.905  0.01154 * 
    PG               -3.666e+04  1.192e+04  -3.076  0.00821 **
    GNPA             -2.993e-02  3.511e-02  -0.852  0.40836   
    NLPG              1.224e-02  1.115e-01   0.110  0.91413   
    Year             -4.533e+04  1.381e+04  -3.284  0.00544 **
    factor(Quarter)2 -6.153e+03  6.854e+04  -0.090  0.92974   
    factor(Quarter)3  1.415e+05  1.422e+05   0.995  0.33655   
    factor(Quarter)4 -6.844e+04  9.247e+04  -0.740  0.47144   
    GNPAlag1         -5.707e-03  2.449e-02  -0.233  0.81914   
    NDGV:PG           1.206e+02  4.011e+01   3.007  0.00941 **
    GNPA:NLPG        -2.004e-08  9.308e-09  -2.153  0.04923 * 
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 27980 on 14 degrees of freedom
      (5 observations deleted due to missingness)
    Multiple R-squared:  0.9816,	Adjusted R-squared:  0.9658 
    F-statistic:  62.2 on 12 and 14 DF,  p-value: 5.237e-10
    



    
    Call:
    lm(formula = UGS ~ GNPC + NDGV * PG + GNPA * NLPG + Year + factor(Quarter) + 
        GNPClag1, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -30471 -12557    714   9561  40923 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)    
    (Intercept)       1.042e+08  2.236e+07   4.663 0.000366 ***
    GNPC              1.469e-01  5.046e-02   2.910 0.011412 *  
    NDGV             -5.230e+04  1.535e+04  -3.406 0.004259 ** 
    PG               -3.550e+04  9.794e+03  -3.625 0.002760 ** 
    GNPA             -3.885e-02  3.017e-02  -1.287 0.218806    
    NLPG             -1.916e-02  9.676e-02  -0.198 0.845898    
    Year             -4.413e+04  1.189e+04  -3.712 0.002322 ** 
    factor(Quarter)2  1.358e+05  6.795e+04   1.999 0.065406 .  
    factor(Quarter)3  3.240e+05  1.366e+05   2.372 0.032593 *  
    factor(Quarter)4 -1.187e+05  4.796e+04  -2.474 0.026752 *  
    GNPClag1          7.543e-02  3.377e-02   2.233 0.042355 *  
    NDGV:PG           1.162e+02  3.308e+01   3.511 0.003457 ** 
    GNPA:NLPG        -2.150e-08  8.030e-09  -2.678 0.018023 *  
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 24070 on 14 degrees of freedom
      (5 observations deleted due to missingness)
    Multiple R-squared:  0.9864,	Adjusted R-squared:  0.9747 
    F-statistic: 84.45 on 12 and 14 DF,  p-value: 6.509e-11
    



    
    Call:
    lm(formula = UGS ~ GNPC + NDGV * PG + GNPA * NLPG + Year + factor(Quarter) + 
        GNPTlag1, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -38046  -9442  -1782   8709  39577 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)    
    (Intercept)       1.195e+08  2.512e+07   4.758 0.000306 ***
    GNPC              1.385e-01  5.688e-02   2.435 0.028858 *  
    NDGV             -4.284e+04  1.754e+04  -2.442 0.028472 *  
    PG               -2.939e+04  1.121e+04  -2.621 0.020135 *  
    GNPA             -4.106e-02  3.282e-02  -1.251 0.231513    
    NLPG              4.325e-03  1.024e-01   0.042 0.966923    
    Year             -5.314e+04  1.359e+04  -3.909 0.001574 ** 
    factor(Quarter)2  1.137e+05  7.663e+04   1.483 0.160209    
    factor(Quarter)3  3.311e+05  1.638e+05   2.021 0.062780 .  
    factor(Quarter)4 -9.470e+04  4.917e+04  -1.926 0.074646 .  
    GNPTlag1          1.205e-02  7.482e-03   1.610 0.129647    
    NDGV:PG           9.604e+01  3.791e+01   2.533 0.023871 *  
    GNPA:NLPG        -1.778e-08  8.663e-09  -2.052 0.059312 .  
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 25750 on 14 degrees of freedom
      (5 observations deleted due to missingness)
    Multiple R-squared:  0.9844,	Adjusted R-squared:  0.971 
    F-statistic: 73.65 on 12 and 14 DF,  p-value: 1.658e-10
    


Lagged variables that improved the model most are added together to the model. With these variables, the adjusted R-squared value of the model increased to 0.9787 which is good enough.


```R
model <- lm(UGS~GNPC+NDGV*PG+GNPA*NLPG+Year+factor(Quarter)+GNPClag1+NLPGlag1+RNUVlag1, data=gasoline)
summary(model)
plot(model)
```


    
    Call:
    lm(formula = UGS ~ GNPC + NDGV * PG + GNPA * NLPG + Year + factor(Quarter) + 
        GNPClag1 + NLPGlag1 + RNUVlag1, data = gasoline)
    
    Residuals:
       Min     1Q Median     3Q    Max 
    -27942  -9385   1749   8741  35594 
    
    Coefficients:
                       Estimate Std. Error t value Pr(>|t|)   
    (Intercept)       1.211e+08  2.997e+07   4.041  0.00164 **
    GNPC              1.049e-01  5.037e-02   2.082  0.05939 . 
    NDGV             -5.407e+04  1.495e+04  -3.617  0.00354 **
    PG               -3.676e+04  9.429e+03  -3.899  0.00211 **
    GNPA             -8.909e-03  3.453e-02  -0.258  0.80078   
    NLPG             -1.250e-01  2.286e-01  -0.547  0.59459   
    Year             -5.232e+04  1.592e+04  -3.286  0.00650 **
    factor(Quarter)2  1.483e+05  6.278e+04   2.362  0.03593 * 
    factor(Quarter)3  3.046e+05  1.443e+05   2.110  0.05649 . 
    factor(Quarter)4 -1.043e+05  6.618e+04  -1.576  0.14093   
    GNPClag1          7.909e-02  3.417e-02   2.315  0.03913 * 
    NLPGlag1          2.517e-01  2.482e-01   1.014  0.33062   
    RNUVlag1         -1.785e+06  1.193e+06  -1.497  0.16022   
    NDGV:PG           1.206e+02  3.176e+01   3.798  0.00254 **
    GNPA:NLPG        -2.928e-08  8.504e-09  -3.443  0.00487 **
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 22100 on 12 degrees of freedom
      (5 observations deleted due to missingness)
    Multiple R-squared:  0.9902,	Adjusted R-squared:  0.9787 
    F-statistic:  86.2 on 14 and 12 DF,  p-value: 8e-10
    



    
![png](output_27_1.png)
    



    
![png](output_27_2.png)
    



    
![png](output_27_3.png)
    



    
![png](output_27_4.png)
    


### 6. Prediction Using the Constructed Regression Model


```R
gasoline$predicted <- predict(model, gasoline)
gasoline$residuals <- gasoline$UGS-gasoline$predicted

#Comparing residuals and variables of the model

ggplot(gasoline[2:28,], aes(x=UGS))+geom_point(aes(y=residuals),color="red")+
  labs(title="Residuals vs Actual values")

ggplot(gasoline[2:28,], aes(x=predicted))+geom_point(aes(y=residuals),color="red")+
  labs(title="Residuals vs Predicted values")

ggplot(gasoline[2:28,], aes(x=GNPC))+geom_point(aes(y=residuals),color="red")+
  labs(title="Residuals vs GNPC")
ggplot(gasoline[2:28,], aes(x=NDGV))+geom_point(aes(y=residuals),color="red")+
  labs(title="Residuals vs NDGV")
ggplot(gasoline[2:28,], aes(x=PG))+geom_point(aes(y=residuals),color="red")+
  labs(title="Residuals vs PG")
ggplot(gasoline[2:28,], aes(x=NLPG))+geom_point(aes(y=residuals),color="red")+
  labs(title="Residuals vs NLPG")

ggplot(gasoline[1:28,], aes(x=predicted))+geom_point(aes(y=UGS),color="red")+
  labs(title="Actual vs predicted values")+
  geom_abline(slope=1)
```


    
![png](output_29_0.png)
    



    
![png](output_29_1.png)
    



    
![png](output_29_2.png)
    



    
![png](output_29_3.png)
    



    
![png](output_29_4.png)
    


    Warning message:
    "Removed 1 rows containing missing values (geom_point)."


    
![png](output_29_6.png)
    



    
![png](output_29_7.png)
    


Residials seems to be random enough without huge changes in variation. This is a good sign that shows the accuracy of the model. Also from the Predicted vs Actual values graph, we can see that the predictions follow a line with slope = 1 which also shows the accuracy of the model.


```R
ggplot(gasoline, aes(x=Date))+geom_line(aes(y=UGS),color="red")+
  geom_line(aes(y=predicted),color="blue")+
  labs(x="Date",y="UGS",title="Quarterly Gasoline Sales (Red) vs Predicted Values (Blue)")

gasoline$predicted[29:32]

ggplot(gasoline[29:32,], aes(x=Date))+
  geom_line(aes(y=predicted),color="blue")+
  labs(x="Date",y="UGS",title="Predicted Values for 2007")
```

    Warning message:
    "Removed 4 rows containing missing values (geom_path)."Warning message:
    "Removed 1 rows containing missing values (geom_path)."


<ol class=list-inline>
	<li>753864.563275625</li>
	<li>886415.476166209</li>
	<li>955610.373700018</li>
	<li>844115.126152238</li>
</ol>




    
![png](output_31_2.png)
    



    
![png](output_31_3.png)
    


#### Predicted Values
2007 Q1: 753864.563275651

2007 Q2: 886415.476166224

2007 Q3: 955610.373700033

2007 Q4: 844115.126152245

### Conclusion
 model <- lm(UGS~GNPC+NDGV*PG+GNPA*NLPG+Year+factor(Quarter)+GNPClag1+NLPGlag1+RNUVlag1, data=gasoline)
 
Although multiple variables had a good correlation with the target variable UGS, most of them did not fit well together when building the time series regression model for the predictions. As a result, the final model included GNPC, NDGV, PG, GNPA, and NLPG variables are used with parralel to Year, Quarter factor and lagged variables of GNPC, NLPG and RNUV. The UGS values were predicted using the model created with these factors. And, as previously stated, residuals typically did not violate the zero mean, constant variance, normalcy, randomness, and independence requirements. In addition, a comparison of real and anticipated UGS values revealed that the model is accurate. Aside from that, forecasts for the following year are made using the 2007 values of the model's variables.
